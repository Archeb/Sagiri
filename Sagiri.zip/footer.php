		</div>
	</body>
	<?php $this->need('dist/inline-resource.php'); ?>
	<link rel="stylesheet" type="text/css" href="<?php $this->options->themeUrl('/css/style.css'); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php $this->options->themeUrl('/css/font-awesome.min.css'); ?>"/>
</html>
