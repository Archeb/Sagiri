<script src="js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
<script src="js/sagiri.js" type="text/javascript" charset="utf-8"></script>