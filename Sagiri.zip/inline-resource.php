<script src="https://cdn.bootcss.com/aplayer/1.6.0/APlayer.min.js"></script>
<script src="js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
<script src="js/sagiri.js" type="text/javascript" charset="utf-8"></script>